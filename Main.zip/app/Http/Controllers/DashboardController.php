<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
{
 return view('posts.dashboard', [
 'totalProjects' => Projects::count(),
 'totalCategories' => Category::count(),
 'totalTechnologies' => Technology::count(),
 'totalSkills' => Skill::count(),
 'latestProjects' => Project::with('category')->latest()->take(5)->get(),
 ]);
}
}
