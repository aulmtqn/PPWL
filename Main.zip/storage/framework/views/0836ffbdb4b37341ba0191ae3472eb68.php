<?php $__env->startSection('title', 'Home - Portfolio'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Selamat Datang di Portfolio Saya</h1>
    <p>Ini halaman Home nyaaa.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp2\htdocs\PPWL\resources\views/home.blade.php ENDPATH**/ ?>