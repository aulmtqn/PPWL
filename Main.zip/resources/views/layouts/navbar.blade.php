
<nav>
    <ul class="nav-menu">
        <li><a href="{{ route('home') }}">Home</a></li>
        <li><a href="{{ route('about') }}">About</a></li>
        <li><a href="{{ route('education') }}">Education</a></li>
        <li><a href="{{ route('projects.index') }}">Projects</a></li>
    </ul>
</nav>
